var startApp = function() {
  // alert('started');
};